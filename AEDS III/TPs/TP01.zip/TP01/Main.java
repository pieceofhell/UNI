public class Main {

  public static void main(String[] args) {
    try {
      JQL.startJQL();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
