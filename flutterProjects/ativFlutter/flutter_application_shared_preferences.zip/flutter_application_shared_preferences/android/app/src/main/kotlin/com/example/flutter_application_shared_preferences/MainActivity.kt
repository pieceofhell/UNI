package com.example.flutter_application_shared_preferences

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
