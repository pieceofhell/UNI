package com.example.flutter_application_api_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
